//
//  ViewController.swift
//  CaourseraHamburguesa
//
//  Created by Alejandra Rodtiguez on 03/07/16.
//  Copyright (c) 2016 Poliformo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //Interface builder outlet: crea una referencia
    //weak: memoria. Si no se usa el objeto no se crea una referencia
    // UILabel opfional porque en algún momento puede tener un valor nulo
    
    @IBOutlet weak var pais: UILabel!
    
    @IBOutlet weak var hamburguesa: UILabel!
    
    let colores = Colores()
    let paises = coleccionDePaises()
    let comerHamburguesa = coleccionDeHamburguesas()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Interface builder action: va a ejecutar alguna acción cuando tu le des click al boton
    
    @IBAction func quieroMiHamburguesa() {
        let colorAleatorio = colores.regresaColorAleatorio()
        view.backgroundColor = colorAleatorio
        view.tintColor = colorAleatorio
        pais.text = paises.regresaPaisAleatorio()
        hamburguesa.text = comerHamburguesa.regresaHamburguesaAleatoria()
    }
    
    
}

