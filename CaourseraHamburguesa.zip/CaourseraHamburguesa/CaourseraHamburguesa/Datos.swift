//
//  Datos.swift
//  CaourseraHamburguesa
//
//  Created by Alejandra Rodtiguez on 03/07/16.
//  Copyright (c) 2016 Poliformo. All rights reserved.
//

import Foundation
struct coleccionDePaises {
    let paises = [ "Mexico", "Canada", "EUA", "China", "Japón", "Inglaterra", "Francia", "Alemania", "Italia", "Grecia", "Portugal", "España" , "Egipto", "Taiwan", "Argentina", "Brasil", "Chile", "Nicaragua", "Cuba", "Sudafrica", "Korea", "India", "Emiratos Arabes Unidos"]
    
    func regresaPaisAleatorio () -> String {
        let posicion = Int(arc4random()) % paises.count
        return paises[posicion]
    }
}

struct coleccionDeHamburguesas {
    let hamburguesa = [ "Hamburguesa con papas", "Cheeseburger", "veggie burger", "Shake Shak", "Burguer King", "McDonalds", "Farm Burguer", "Hamburguesa doble"]
    
    func regresaHamburguesaAleatoria () -> String {
        let posicion = Int(arc4random()) % hamburguesa.count
        return hamburguesa[posicion]
    }
}